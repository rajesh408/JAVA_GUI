import javax.swing.*;
import java.awt.event.*;

public class FileDialogTest1 implements ActionListener
{
    JFileChooser fc;
    JFrame fr;
    JButton jb;
    public FileDialogTest1()
    {
        fr=new JFrame("File Test");
        fr.setLayout(null);

        fc=new JFileChooser();

        jb=new JButton("open");
        jb.setBounds(50,50,100,100);

        fr.add(jb);
        fr.setSize(300,300);
        fr.setVisible(true);

        jb.addActionListener(this);

    }
    public void actionPerformed(ActionEvent e)
    {
        int i=fc.showOpenDialog(fr);
        System.out.println("you are selected "+i);
    }
    public static void main (String[] args)
    {
try {
            	for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
		 {
               		 if ("Nimbus".equals(info.getName())) 
			{
                    		UIManager.setLookAndFeel(info.getClassName());
                    		break;
               	 	}
            	}
        } catch (Exception ex) {}
		
        new FileDialogTest1();
    }

}
