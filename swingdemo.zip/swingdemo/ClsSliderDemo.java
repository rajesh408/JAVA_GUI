/**
* Program to demonstrate JSlider
*/

import javax.swing.*;
import javax.swing.event.*;

class ClsSliderDemo implements ChangeListener
{
	JFrame objFrame;
	JSlider objSlider;
	JLabel objLabel;
	
	ClsSliderDemo()
	{
		objFrame = new JFrame();
		objFrame.setLayout(null);

		objSlider = new JSlider();
		objLabel = new JLabel();

		objSlider.setMajorTickSpacing(5);
		objSlider.setPaintTicks(true);
		objSlider.setPaintLabels(true);
		objSlider.setSnapToTicks(true);

		objSlider.setBounds(50, 50, 250, 50);
		objLabel.setBounds(100, 120, 100, 50);

		objFrame.add(objSlider);
		objFrame.add(objLabel);

		objFrame.setSize(400, 300);
		objFrame.setVisible(true);

		objSlider.addChangeListener(this);
	}

	public void stateChanged(ChangeEvent e)
	{
		int val = objSlider.getValue();
		objLabel.setText(val + "%");
	}

	public static void main(String[] args)
	{
		new ClsSliderDemo();
	}
}








