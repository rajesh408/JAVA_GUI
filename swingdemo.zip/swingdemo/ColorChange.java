import javax.swing.*;
import java.awt.*;
import javax.swing.event.*;

public class ColorChange implements ChangeListener
{
    JSlider    jsclrB,jsclrG,jsclrR;
    JTextField tf;
    JFrame jf;
    JScrollPane jp;

    public ColorChange()
    {
	
        jf=new JFrame();
        jf.setLayout(null);

        jf.setLocation(10,10);


        jsclrB =new JSlider();

        jsclrB.setPaintTicks(true);

        jsclrB.setMajorTickSpacing(15);

        jsclrB.setPaintLabels(true);
        jsclrB.setSnapToTicks( true );

        jsclrB.setMaximum(255);
        jsclrB.setMinimum(0);

        jsclrR =new JSlider();
        jsclrR.setPaintTicks(true);
        jsclrR.setMajorTickSpacing(15);
        jsclrR.setPaintLabels( true );
        jsclrR.setSnapToTicks( true );
        jsclrR.setMaximum(255);
        jsclrR.setMinimum(0);

        jsclrG =new JSlider();
        jsclrG.setPaintTicks(true);
        jsclrG.setMajorTickSpacing(20);
        jsclrG.setPaintLabels( true );
        jsclrG.setSnapToTicks( true );
        jsclrG.setMaximum(255);
        jsclrG.setMinimum(0);

        tf=new JTextField();
        tf.setEditable(false);

        tf.setBounds(50,50,300,100);
        jsclrR.setBounds(0,200,800,80);
        jsclrG.setBounds(0,270,1020,80);
        jsclrB.setBounds(0,350,1020,80);

        jf.add(tf);
        jf.add(jsclrB);
        jf.add(jsclrG);
        jf.add(jsclrR);


        jf.setSize(800,800);
        jf.setVisible(true);

        jsclrB.addChangeListener(this);
        jsclrG.addChangeListener(this);
        jsclrR.addChangeListener(this);
	
    }

    public void stateChanged(ChangeEvent e)
    {
        int i=jsclrB.getValue();
        int j=jsclrG.getValue();
        int k=jsclrR.getValue();
        if(e.getSource()==jsclrB)
        {
            Color c=new Color(k,j,i);
            tf.setBackground(c);
        }
        if(e.getSource()==jsclrG)
        {
            Color c=new Color(k,j,i);
            tf.setBackground(c);
        }
        if(e.getSource()==jsclrR)
        {
            Color c=new Color(k,j,i);
            tf.setBackground(c);
        }
    }
    public static void main (String[] args)
    {
        new ColorChange();
    }

}
