class booltest
{
	public static void main(String [] ar)
	{
		boolean a=false;
		System.out.println(!a);
	}
}