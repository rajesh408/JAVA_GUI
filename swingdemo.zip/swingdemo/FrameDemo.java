import javax.swing.*;
class FrameDemo extends JFrame
{
	JFrame f;
	
	public FrameDemo()
	{
		f=new JFrame("My Frame Demo");
		f.setSize(600,600);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
		new FrameDemo();
	}
}