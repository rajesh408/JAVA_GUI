import javax.swing.*;
import java.awt.*;
class checkdemo	extends JFrame
{
	JFrame f;
	JPanel p;
	
	JCheckBox ck1,ck2;

	public checkdemo()
	{
		
		
		
		f=new JFrame("My Frame Demo");
		f.setLayout(null);
		p=new JPanel();
		p.setSize(400,400);
		p.setVisible(true);
		
		ck1=new JCheckBox("C");
		ck2=new JCheckBox("C++");

		
		p.add(ck1);
		p.add(ck2);

		f.add(p);
		
		f.setSize(400,400);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
	try {
            	for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
		 {
               		 if ("Nimbus".equals(info.getName())) 
			{
                    		UIManager.setLookAndFeel(info.getClassName());
                    		break;
               	 	}
            	}
        } catch (Exception ex) {}
		
		new checkdemo();
		
	}
}