import javax.swing.*;
import java.awt.*;
class menubardemo extends JFrame
{
	JFrame f;
	JMenuBar mb;

	public  menubardemo()
	{
		f=new JFrame("My Frame Demo");
		f.setLayout(null);
		
		mb=new JMenuBar();
		
		f.setMenuBar();
		
		f.setSize(400,400);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
	try {
            	for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
		 {
               		 if ("Nimbus".equals(info.getName())) 
			{
                    		UIManager.setLookAndFeel(info.getClassName());
                    		break;
               	 	}
            	}
        } catch (Exception ex) {}
		
		new  menubardemo();
		
	}
}