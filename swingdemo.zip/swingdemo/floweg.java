import java.awt.*;
import javax.swing.*;

public class  floweg extends JFrame
{
	JFrame f;
	
	JButton b1,b2,b3;
	
	FlowLayout fl;
	
	floweg()
	{
		f=new JFrame("Flow Example..!");
		f.setLayout(new FlowLayout(FlowLayout.LEFT));
		b1=new JButton("Button1");
		b2=new JButton("Button2");
		b3=new JButton("Button3");
		f.add(b1);
		f.add(b2);
		f.add(b3);
		f.setSize(500,500);
		f.setVisible(true);
	}
public static void main(String [] ar)
	{
		new floweg();
	}

}