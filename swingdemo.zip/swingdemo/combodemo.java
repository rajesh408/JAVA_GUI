import javax.swing.*;
class combodemo	extends JFrame
{
	JFrame f;
	JPanel p;
	
	JComboBox cb;
	JList l1;

	public combodemo()
	{
		
		String country[] ={"India","USA","China","Australia","Others"};
		
		f=new JFrame("My Frame Demo");
		f.setLayout(null);
		p=new JPanel();
		
		
		p.setSize(400,400);
		p.setVisible(true);
		
		cb=new JComboBox(country);
		cb.setMaximumRowCount(2);
		l1=new JList(country);
		
		p.add(cb);
		p.add(l1);
		f.add(p);
		
		f.setSize(400,400);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
	try {
            	for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
		 {
               		 if ("Nimbus".equals(info.getName())) 
			{
                    		UIManager.setLookAndFeel(info.getClassName());
                    		break;
               	 	}
            	}
        } catch (Exception ex) {}
		
		new combodemo();
		
	}
}