import javax.swing.*;
import java.awt.*;
class JTextAreaDemo extends JFrame
{
	JFrame f;
	JPanel p;
	JLabel l1,l2,l3,l4;
	JTextField t1;
	JPasswordField pw;

	JTextArea ta;
	JScrollPane sp;

	JButton b1;
	Font ft; 
	
	public JTextAreaDemo()
	{
		ft=new Font("monotype corsiva",Font.BOLD,30);
			
		f=new JFrame("My Frame Demo");
		f.setLayout(null);
		p=new JPanel();
		p.setLayout(null);
		p.setBackground(Color.gray);
		
		l1=new JLabel("Welcome to Swings");
		l1.setForeground(Color.blue);
		l1.setFont(ft);
		l1.setBounds(80,10,300,80);
		
		l2=new JLabel("Enter your Name");
		l2.setBounds(20,100,140,30);
		t1=new JTextField(20);
		t1.setBounds(200,100,180,30);
		
		l3=new JLabel("Enter your Password");
		l3.setBounds(20,140,140,30);
		pw=new JPasswordField(20);
		pw.setEchoChar('#');
		pw.setBounds(200,140,180,30);

		l4=new JLabel("Enter your Address");
		l4.setBounds(20,180,140,30);
		
		ta=new JTextArea(3,20);
		sp=new JScrollPane(ta);
		sp.setBounds(200,180,180,80);
		
		b1=new JButton("Submit");
		b1.setBounds(300,260,80,30);

		p.add(l1);
		p.add(l2);
		p.add(t1);
		p.add(l3);
		p.add(pw);
		p.add(l4);
		p.add(sp);
		p.add(b1);
		
		p.setSize(400,400);
		p.setVisible(true);
		
		f.add(p);
		
		f.setSize(400,400);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
	/*try {
            	for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
		 {
               		 if ("Nimbus".equals(info.getName())) 
			{
                    		UIManager.setLookAndFeel(info.getClassName());
                    		break;
               	 	}
            	}
        } catch (Exception ex) {}
	*/	
		new JTextAreaDemo();
		
	}
}