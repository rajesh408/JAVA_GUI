import javax.swing.*;
import java.awt.*;
class JPanelDemo extends JFrame
{
	JFrame f;
	JPanel p;
	
	public JPanelDemo()
	{
		
		f=new JFrame("My Frame Demo");
		f.setLayout(null);
		p=new JPanel();
		p.setBackground(Color.gray);
		
		p.setSize(400,400);
		p.setVisible(true);
		
		f.add(p);
		
		f.setSize(600,600);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
		new JPanelDemo();
	}
}