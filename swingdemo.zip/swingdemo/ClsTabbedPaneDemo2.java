/**
* Program to demonstrate TabbedPane
*/

import javax.swing.*;
import java.awt.event.*;
import java.awt.*; 

class ClsTabbedPaneDemo2 implements ActionListener
{
	JFrame objFrame;
	JPanel p1,p2,p3,p4;
	JTabbedPane objTabbedPane;

	ClsTabbedPaneDemo2()
	{
		objFrame = new JFrame();
		objFrame.setLayout(null);

		p1 = new JPanel();
		p1.setBackground(Color.red);
		p1.setSize(500,500);
		p1.setVisible(true);
		
		p2 = new JPanel();
		p2.setBackground(Color.green);
		p2.setSize(500,500);
		p2.setVisible(true);

		p3 = new JPanel();
		p3.setBackground(Color.yellow);
		p3.setSize(500,500);
		p3.setVisible(true);

		p4 = new JPanel();
		p4.setBackground(Color.blue);
		p4.setSize(500,500);
		p4.setVisible(true);

		objTabbedPane = new JTabbedPane();
		
		objTabbedPane.setBounds(40, 30, 400, 300);
		

		objTabbedPane.addTab("First", p1);
		objTabbedPane.addTab("Second", p2);
		objTabbedPane.addTab("Third", p3);
		objTabbedPane.addTab("Fourth", p4);

		objFrame.add(objTabbedPane);
		

		
		objFrame.setSize(500, 500);
		objFrame.setVisible(true);
	}

	public void actionPerformed(ActionEvent e)
	{
		/*if(e.getSource() == objButton1)
		{
			objTabbedPane.setTabPlacement(JTabbedPane.TOP);
		}

		if(e.getSource() == objButton2)
		{
			objTabbedPane.setTabPlacement(JTabbedPane.BOTTOM);
		}

		if(e.getSource() == objButton3)
		{
			objTabbedPane.setTabPlacement(JTabbedPane.LEFT);
		}

		if(e.getSource() == objButton4)
		{
			objTabbedPane.setTabPlacement(JTabbedPane.RIGHT);
		}*/
	}

	public static void main(String[] args)
	{try {
            	for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
		 {
               		 if ("Nimbus".equals(info.getName())) 
			{
                    		UIManager.setLookAndFeel(info.getClassName());
                    		break;
               	 	}
            	}
        } catch (Exception ex) {}
		
		new ClsTabbedPaneDemo2();
	}
}



