import java.util.Scanner;
class tableeg
{
	public static void main(String [] ar)
	{
		Scanner s=new Scanner(System.in);
		System.out.println("Enter first no.");
		int n1=s.nextInt();	
		System.out.println("Enter second no.");
		int n2=s.nextInt();
		
		if(n1>n2)
		{
			n1=n1+n2;
			n2=n1-n2;
			n1=n1-n2;
		}
		while(n1<=n2)
		{
			for(int a=1;a<=10;a++)
			{
				System.out.println(n1+" * "+a+" = "+(n1*a));
			}
			System.out.println("===============");
		n1++;
		}
	}	
}