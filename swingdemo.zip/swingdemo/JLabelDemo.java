import javax.swing.*;
import java.awt.*;
class JLabelDemo extends JFrame
{
	JFrame f;
	JPanel p;
	JLabel l1;
	Font ft; 
	
	public JLabelDemo()
	{
		ft=new Font("monotype corsiva",Font.BOLD,30);
			
		f=new JFrame("My Frame Demo");
		f.setLayout(null);
		p=new JPanel();
		p.setBackground(Color.gray);
		
		l1=new JLabel("Welcome to Swings");
		l1.setForeground(Color.blue);
		l1.setFont(ft);
		
		p.add(l1);
		
		p.setSize(400,400);
		p.setVisible(true);
		
		f.add(p);
		
		f.setSize(400,400);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
		new JLabelDemo();
	}
}