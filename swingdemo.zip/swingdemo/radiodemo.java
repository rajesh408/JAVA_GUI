import javax.swing.*;
import java.awt.*;
class radiodemo	extends JFrame
{
	JFrame f;
	JPanel p;
	
	JRadioButton r1,r2;
	ButtonGroup bg;	

	public radiodemo()
	{
		
		
		
		f=new JFrame("My Frame Demo");
		f.setLayout(null);
		p=new JPanel();
		p.setSize(400,400);
		p.setVisible(true);
		
		r1=new JRadioButton("Male");
		r2=new JRadioButton("FeMale");

		bg=new ButtonGroup();
		bg.add(r1);
		bg.add(r2);
		
		p.add(r1);
		p.add(r2);

		f.add(p);
		
		f.setSize(400,400);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
	try {
            	for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
		 {
               		 if ("Nimbus".equals(info.getName())) 
			{
                    		UIManager.setLookAndFeel(info.getClassName());
                    		break;
               	 	}
            	}
        } catch (Exception ex) {}
		
		new radiodemo();
		
	}
}