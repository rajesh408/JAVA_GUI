import java.awt.*;
import javax.swing.*;
class boxdemo extends JFrame
{
	public static void main(String [] ar)
	{
		
		JFrame horizontalFrame=new JFrame("Box Eaxmple with horizontal ...!");

		Box hBox=Box.createHorizontalBox();
		
		hBox.add(new JLabel("Top"));
		hBox.add(new JTextField("Middle"));
		hBox.add(new JButton("Bottom"));
		horizontalFrame.getContentPane().add(hBox, BorderLayout.CENTER);
		horizontalFrame.setSize(250, 250);
		horizontalFrame.setVisible(true);
	
		JFrame verticalFrame=new JFrame("Box Eaxmple with Vertical...!");
		
		Box verticalBox = Box.createVerticalBox();
    		verticalBox.add(new JLabel("Top"));
    		verticalBox.add(new JTextField("Middle"));
    		verticalBox.add(new JButton("Bottom"));
    		verticalFrame.getContentPane().add(verticalBox, BorderLayout.CENTER);
    		verticalFrame.setSize(250, 250);
    		verticalFrame.setVisible(true);
		
	}
	
}