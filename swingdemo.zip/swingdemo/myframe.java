import javax.swing.*;
import java.awt.*; 
class myframe extends JFrame
{
JFrame f;
JPanel p;
Color c;	
	myframe()
	{
		c=new Color(243, 166, 110);
		// initializing frame 
		f=new JFrame("My Frame Demo...!");
		f.setRelativePosition(null);
		f.setLayout(null);
		//setting size of frame
		f.setSize(500,500);
		
		//making frame visible
		f.setVisible(true);
		
		p=new JPanel();
		p.setBackground(c);
		p.setSize(400,400);
		p.setVisible(true);
		
		f.add(p);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String []a1)
	{
		new myframe();
	} 
}