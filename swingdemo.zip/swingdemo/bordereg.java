import java.awt.*;
import javax.swing.*;

public class  bordereg extends JFrame
{
	JFrame f;
	
	JButton b1,b2,b3,b4,b5;
	
	BorderLayout bl;
	bordereg()
	{
		
		f=new JFrame("Flow Example..!");
		b1=new JButton("Button1");
		b2=new JButton("Button2");
		b3=new JButton("Button3");
		b4=new JButton("Button4");
		b5=new JButton("Button5");
		f.add(b1,BorderLayout.NORTH);
		f.add(b2,BorderLayout.SOUTH);
		f.add(b3,BorderLayout.EAST);
		f.add(b4,BorderLayout.WEST);
		f.add(b5,BorderLayout.CENTER);
		f.setSize(500,500);
		f.setVisible(true);
	}
public static void main(String [] ar)
	{
		new bordereg();
	}

}