import java.awt.*;
import javax.swing.*;
import java.awt.event.*;

class eventdemo extends JFrame implements ActionListener
{
JFrame f;
JPanel p;
JLabel l1;
JTextField t1;
JButton b1;
	eventdemo()
	{
		f=new JFrame("Event demo");
		p=new JPanel();
		l1=new JLabel("Enter ur name here...!");
		t1=new JTextField(20);
		b1=new JButton("Submit");
		b1.addActionListener(this);
		
		p.add(l1);
		p.add(t1);
		p.add(b1);
		
		p.setSize(400,400);
		p.setVisible(true);
		
		f.add(p);
		
		f.setSize(400,400);
		f.setVisible(true);
	}
public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==b1)
			{
			String s1=t1.getText();
			if(s1.equals(""))
				{
				JOptionPane.showMessageDialog(this,"Please enter name first...!","ERROR",JOptionPane.WARNING_MESSAGE);
			}
			}	
		}
public static void main(String ...ar)
	{
		new eventdemo();
	}
}


















