import java.awt.*;
import javax.swing.*;

public class FlowExample 
{
	private JFrame f;
	private JButton b1, b2, b3, b4, b5;

	public FlowExample() 
	{
	 f = new JFrame("Flow Layout");
	 f.setLayout(new FlowLayout(FlowLayout.RIGHT));
	 b1 = new JButton("Button 1");
	 b2 = new JButton("Button 2");
	 b3 = new JButton("Button 3");
	 b4 = new JButton("Button 4");
	 b5 = new JButton("Button 5");
 	}

	public void launchFrame() 
	{
	 f.add(b1);
	 f.add(b2);
	 f.add(b5);
	
	 f.add(b4);
	 f.add(b3);
	 f.setSize(400,200);
	 f.setVisible(true);
 	}

 public static void main(String args[]) 
	{
	 FlowExample guiWindow2 = new FlowExample();
	 guiWindow2.launchFrame();
 	}
 }