import java.awt.*;
import javax.swing.*;
class menubardemo extends JFrame
{
	JFrame f;
	JMenuBar mb;
	JMenu m1,m2,m3;
	JMenuItem mi1,mi2,mi3,mi4,mi5;
	JCheckBoxMenuItem cbmi;
	public menubardemo()
	{
		f=new JFrame("MenuBar Demo...!");
		mb=new JMenuBar();
		mb.setBackground(Color.green);
		
		m1=new JMenu("File");
		m2=new JMenu("Edit");
		m3=new JMenu("Format");
		
		mi1=new JMenuItem("New");
		mi2=new JMenuItem("open");
		mi3=new JMenuItem("copy");
		mi4=new JMenuItem("paste");
		mi5=new JMenuItem("Font");
		
		cbmi=new JCheckBoxMenuItem("Word Wrap");
		
		m1.add(mi1);	
		m1.addSeparator();	
		m1.add(mi2);
		
		m2.add(mi3);
		m2.add(mi4);
		
		m3.add(mi5);
		m3.add(cbmi);

		mb.add(m1);
		mb.add(m2);
		mb.add(m3);

		f.setJMenuBar(mb);
		f.setSize(500,700);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String []ar)
	{
		new menubardemo();
	}
}