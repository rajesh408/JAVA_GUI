import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class eventdemo extends JFrame implements ActionListener
{
	JFrame f;
	JPanel p;
	JLabel l1,l2;
	JTextField t1;
	JButton b1 ;
	
	public 	eventdemo()
	{
		f=new JFrame("Event Demo.......!");
		p=new JPanel();
		l1=new JLabel("Enter u r Name :");
		l2=new JLabel("");
		t1=new JTextField(20);
		b1=new JButton("SUBMIT");
		b1.addActionListener(this);
		p.add(l1);
		p.add(t1);
		p.add(b1);
		p.add(l2);
		p.setSize(500,500);
		p.setVisible(true);
		f.add(p);
		f.setSize(500,500);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}	
public void actionPerformed(ActionEvent ae)
	{
		if(ae.getSource()==b1)
		{
			String s1=t1.getText();
			l2.setText("Hello Mr./Mrs "+s1);
		}
	}
public static void main(String []arg)
	{
		new eventdemo();
	}
}