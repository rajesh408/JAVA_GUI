import java.awt.*;
import javax.swing.*;
class myframe extends JFrame
{
	JFrame f;
	JPanel p;
	JLabel l1,l2,l3;
	JTextField t1;
	JPasswordField p1;
	JComboBox cb1;
	JButton b1;
	Color c; 
	Font ft;
	JRadioButton rb1,rb2;
	ButtonGroup rbg;
	TextArea ta;	
	public  myframe()
	{
		String []s1={"PHP","JAVA","C++","Oracle","C#"}; 
		ft=new Font("Monotype corsiva",Font.BOLD,25);
		c=new Color(145,120,233);
		f=new JFrame("Herojit Frame..!");
		f.setLayout(null);
		p=new JPanel();
		p.setBackground(c);
		
		cb1=new JComboBox(s1);	
		cb1.setMaximumRowCount(3);
		
		rb1=new JRadioButton("Male");	
		rb2=new JRadioButton("Female");
		
		rbg=new ButtonGroup();
		rbg.add(rb1);
		rbg.add(rb2);
	
		ta=new TextArea(4,16);
		
		
		l1=new JLabel("Enter u r Username");
		l1.setForeground(Color.orange);
		l1.setFont(ft);
		l2=new JLabel("Enter u r Password");
		l2.setForeground(Color.orange);
		l2.setFont(ft);
		
		l3=new JLabel("Enter u r Address");
		l3.setForeground(Color.orange);
		l3.setFont(ft);
		
		t1=new JTextField(20);
		t1.setForeground(Color.blue);
		t1.setBackground(Color.gray);
		p1=new JPasswordField(20);
		p1.setForeground(Color.blue);
		p1.setBackground(Color.gray);
		b1=new JButton("SUBMIT");
		p.add(l1);
		p.add(t1);
		p.add(l2);
		p.add(p1);
		
		p.add(l3);
		p.add(ta);
		
		p.add(cb1);
		
		p.add(rb1);
		p.add(rb2);
		
		p.add(b1);
		
		p.setSize(500,600);
		p.setVisible(true);
		f.add(p);
		f.setSize(500,600);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public static void main(String []ar)
	{
		new myframe();
	}
}