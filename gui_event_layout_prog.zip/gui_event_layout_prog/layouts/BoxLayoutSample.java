import java.awt.BorderLayout;

import javax.swing.Box;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;

public class BoxLayoutSample {
  public static void main(String args[]) {
    JFrame verticalFrame = new JFrame("Vertical");
    verticalFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

    Box verticalBox = Box.createVerticalBox();
    verticalBox.add(new JLabel("Top"));
    verticalBox.add(new JTextField("Middle"));
    verticalBox.add(new JButton("Bottom"));
    verticalFrame.getContentPane().add(verticalBox, BorderLayout.CENTER);
    verticalFrame.setSize(150, 150);
    verticalFrame.setVisible(true);

    JFrame horizontalFrame = new JFrame("Horizontal");

    Box horizontalBox = Box.createHorizontalBox();
    horizontalBox.add(new JLabel("Left"));
    horizontalBox.add(new JTextField("Middle"));
    horizontalBox.add(new JButton("Right"));
    horizontalFrame.getContentPane()
        .add(horizontalBox, BorderLayout.CENTER);
    horizontalFrame.setSize(150, 150);
    horizontalFrame.setVisible(true);
  }
}