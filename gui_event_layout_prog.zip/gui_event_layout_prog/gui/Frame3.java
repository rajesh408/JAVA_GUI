import java.awt.*;

class Frame3 extends Frame{

	Frame3(){

// Code for create label and TextField to write content over it

	Label l1=new Label("Enter Num1 :");
	TextField tf1=new TextField(20);

//set label and textfield on frame
	
	l1.setBounds(40,50,100,30);
	tf1.setBounds(160,50,100,30);

	Label l2=new Label("Enter Num2 :");
	TextField tf2=new TextField(20);

	l2.setBounds(40,100,100,30);
	tf2.setBounds(160,100,100,30);


	Button b1=new Button("Add");
	Button b2=new Button("Minus");

	b1.setBounds(40,150,60,30);
	b2.setBounds(160,150,60,30);


//set background color

	setBackground(Color.pink);
	tf1.setBackground(Color.blue);
	tf2.setBackground(Color.white);

	Color clr1=new Color(222,222,102);
	Color clr2=new Color(111,000,000);

	
	b1.setBackground(clr1);
	b2.setBackground(clr2);

// Set font size

//Font("font_name","font_style",font_size);

	Font f=new Font("Lucida Fax",Font.ITALIC,14);
	l1.setFont(f);
	l2.setFont(f);


//step1: Add components to Frame

	add(l1);
	add(tf1);

	add(l2);
	add(tf2);

	add(b1);
	add(b2);

//Step2 : Set FrameSize

	setSize(300,300);

//Step3: bydefault layout is BorderLayout right now this is null
	
	setLayout(null);

//Step4: used true for frame visulaziation, Bydefault not visible

	setVisible(true);

	

	}
	public static void main(String... kk){

		new Frame3();
		
	}

}
