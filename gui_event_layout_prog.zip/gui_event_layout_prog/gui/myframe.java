import java.awt.*;
import javax.swing.*;
class myframe extends JFrame
{
	JFrame f;
	JPanel p;
	JLabel l1,l2,l3,l4;
	JTextField t1;
	JPasswordField p1;
	JButton b1;
	Font ft;
	JComboBox cb1;
	JRadioButton rb1,rb2;
	ButtonGroup bg;
	public myframe()
	{
		String s1[]={"JAVA","PHP","C","C++","ASP.Net"};
		cb1=new JComboBox(s1);
		cb1.setMaximumRowCount(3);
		ft=new Font("Monotype Corsiva",Font.BOLD,25);
		f=new JFrame("My Frame Demo...........!");
		f.setLayout(null);
		p=new JPanel();
		p.setBackground(Color.orange);

		rb1=new JRadioButton("MALE");
		rb2=new JRadioButton("FEMALE");

		bg=new ButtonGroup();
		bg.add(rb1);
		bg.add(rb2);
		

		l1=new JLabel("USERNAME");
		l1.setFont(ft);
		l1.setForeground(Color.red);
		l2=new JLabel("PASSWORD");
		l2.setFont(ft);
		l2.setForeground(Color.red);
		l3=new JLabel("COURSE");
		l3.setFont(ft);
		l3.setForeground(Color.red);
		l4=new JLabel("GENDER");
		l4.setFont(ft);
		l4.setForeground(Color.red);
		t1=new JTextField(20);
		t1.setForeground(Color.blue);
		t1.setBackground(Color.pink);
		p1=new JPasswordField(20);
		p1.setForeground(Color.blue);
		p1.setBackground(Color.pink);
		b1=new JButton("Submit");
		p.add(l1);
		p.add(t1);
		p.add(l2);
		p.add(p1);
		p.add(l3);
		p.add(cb1);
		p.add(l4);
		p.add(rb1);
		p.add(rb2);
		p.add(b1);
		p.setSize(400,400);
		p.setVisible(true);
		f.add(p);
		f.setSize(500,500);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String []arg )
	{
		new myframe();
	}

}