import javax.swing.*;
import java.awt.*;
public class paneldemo
{
	JFrame f;
	JPanel p;
	paneldemo()
	{
		f=new JFrame("Swing Frame Demo.....! ");
		f.setLayout(null);
		p=new JPanel();
		p.setBackground(Color.green);
		p.setSize(300,300);
		p.setVisible(true);
		f.add(p);
		f.setSize(500,500);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
		new paneldemo();
	}
}