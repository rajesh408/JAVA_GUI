import java.awt.*;
import javax.swing.*;
class menubardemo extends JFrame
{
	JFrame f;
	JMenuBar mb;
	JMenu m1,m2,m3;
	JMenuItem mi1,mi2,mi3,mi4,mi5;
	JCheckBoxMenuItem cb1;
	public menubardemo()
	{
		f=new JFrame("MenuBar demo.......!");
		mb=new JMenuBar();
		mb.setBackground(Color.orange);
		m1=new JMenu("File");
		m2=new JMenu("Edit");
		m3=new JMenu("Format");
		mi1=new JMenuItem("New");	
		mi2=new JMenuItem("Open");
		mi3=new JMenuItem("cut");
		mi4=new JMenuItem("paste");
		mi5=new JMenuItem("Font");
		cb1=new JCheckBoxMenuItem("Word Wrap");
		
		m1.add(mi1);
		m1.addSeparator();
		m1.add(mi2);
		m2.add(mi3);
		m2.add(mi4);
		m3.add(mi5);
		m3.add(cb1);
		
		mb.add(m1);
		mb.add(m2);
		mb.add(m3);
		f.setJMenuBar(mb);
		f.setSize(600,600);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);	
	}
public static void main(String [] ar)
	{
		new menubardemo();
	}
}