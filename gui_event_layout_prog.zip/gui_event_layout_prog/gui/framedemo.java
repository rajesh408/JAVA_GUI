import javax.swing.*;
public class framedemo
{
	JFrame f;
	framedemo()
	{
		f=new JFrame("Swing Frame Demo.....! ");
		f.setSize(500,500);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
		new framedemo();
	}
}