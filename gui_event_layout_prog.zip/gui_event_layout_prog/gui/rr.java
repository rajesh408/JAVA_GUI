public class rr
{
private static int x;
	public static void main(String [] ar)
	{
		System.out.println(x);	
	}
}
