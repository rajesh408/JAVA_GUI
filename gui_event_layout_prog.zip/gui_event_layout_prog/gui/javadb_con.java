import java.sql.*;
class javadb_con
{
	public static void main(String [] ar)
	{
		try
		{
			Class.forName("com.mysql.jdbc.Driver");
Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/aptechdb","root","root");
			PreparedStatement pst=con.prepareStatement("select * from student");
			ResultSet rs=pst.executeQuery();
			
			System.out.println("Sid		Name	 Age");
			
			while(rs.next())
			{
				String sid=rs.getString("sid");
				String nm=rs.getString(2);
				int age=rs.getInt("age");
				
				System.out.println(sid+"	"+nm+"		"+age);
			}
		}
		catch(SQLException se)
		{
			System.out.println("Database Error "+se);		
		}
		catch(Exception e)
		{
			System.out.println("Error "+e);
		}
		
	}
}