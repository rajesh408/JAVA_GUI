import java.sql.*;
class access_db_con
{
	public static void main(String [] arg)
	{
		try
		{
		Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
		Connection con=DriverManager.getConnection("jdbc:odbc:aptechdsn","","");	
		Statement st=con.createStatement();
		ResultSet rs=st.executeQuery("select * from student");
			while(rs.next())
			{
				System.out.println(
						   rs.getString(1) +" "+
						   rs.getString(2) +" "+
						   rs.getString(3) +" "+
						   rs.getInt(4)
						  );
			}
		}
		catch(Exception e)
		{
		System.out.println("error "+e);
		}
	}

}