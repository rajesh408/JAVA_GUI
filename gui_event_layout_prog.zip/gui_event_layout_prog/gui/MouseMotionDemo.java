/** example of MouseMotion Event and MouseMotionListener **/
//move the mouse over the screen and the color of frame changes

import java.awt.*;
import java.awt.event.*;

public class MouseMotionDemo extends Frame implements MouseMotionListener {
	
	TextField textField;
	
	int x;
	int y;
		
	public MouseMotionDemo(String title){
		super(title);  
		textField = new TextField("The mouse cordinates are : 0 AND 0");
		
		//set FLowLayout to the frame		
		setLayout(new FlowLayout()); 

		//add textfield to the frame	
		add(textField,BorderLayout.CENTER);
		
		//register the action listener to the redbutton and blue button
		addMouseMotionListener(this);

	}

	public void mouseDragged(MouseEvent me){

		x=me.getX();
		y=me.getY();
		
		textField.setText("the mouse dragged at " + x + "and" + y + "coordinates");
	}

	public void mouseMoved(MouseEvent me){
		x=me.getX();
		y=me.getY();
this.setBackground(Color.getHSBColor(x,x-y,y));
		textField.setText("the mouse MOVED at " + x + "and" + y + "coordinates");
		
	}

	public static void main(String args[]){
		MouseMotionDemo obj=new MouseMotionDemo("Example of ActionEvent");
		obj.setSize(300,300);
		obj.setVisible(true);

	}
}
