import java.awt.Frame;
import java.awt.Button;
class myawtframe extends Frame
{
Frame f;
Button b;

	myawtframe()
	{
	f=new Frame("My AWT Frame demo");	
	f.setLayout(null);
	b=new Button("Submit");
	b.setBounds(100,60,80,30);

	f.add(b);
	f.setSize(400,500);
	f.setVisible(true);
	}
	public static void main(String []ar)
	{
			new myawtframe();
	}

}