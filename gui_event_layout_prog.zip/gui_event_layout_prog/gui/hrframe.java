import java.awt.*;
import javax.swing.*;
class hrframe extends JFrame
{
	JFrame f;
	JPanel p1,p2;
	JLabel l1;
	JButton b1;
	JInternalFrame jf;
	JDesktopPane d1;
	ImageIcon img;
	hrframe()
	{
		f=new JFrame("Harleen Frame");
		b1=new JButton("submit");
		
		img=new ImageIcon("gg.jpg");
		l1=new JLabel("Star",img,JLabel.CENTER);
		
		//b1.setIcon(img);
		p1=new JPanel();
		p2=new JPanel();
		p2.add(l1);
		p2.add(b1);
		
		p1.setSize(150,150);
		p2.setSize(150,150);
		p1.setVisible(true);
		p2.setVisible(true);
		
		p1.setBackground(Color.green);
		p2.setBackground(Color.red);
		
		d1=new JDesktopPane();
		d1.setSize(400,400);
		jf=new JInternalFrame("Internal Frame",true,true);
		jf.add(p2);
		jf.setSize(200,200);
		jf.setVisible(true);

		//setContentPane(d1);
		d1.add(jf);
		f.add(p1);
		f.add(d1);
		f.setSize(500,600);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
public static void main(String [] arg)
	{
	new hrframe();
	}
}
