import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
public class checkboxevent implements ItemListener
{
	JFrame f;
	JPanel p;
	JCheckBox cb1,cb2,cb3;
	JLabel l1;
String course="";
	checkboxevent()
	{
		f=new JFrame("CheckBox Event Demo...!");
		f.setLayout(null);
		p=new JPanel();
		cb1=new JCheckBox("JAVA");
		cb2=new JCheckBox("PHP");
		cb3=new JCheckBox("C++");
		cb1.addItemListener(this);
		cb2.addItemListener(this);
		cb3.addItemListener(this);
		l1=new JLabel("");
		p.add(cb1);
		p.add(cb2);
		p.add(cb3);
		p.add(l1);
		p.setSize(500,500);
		p.setVisible(true);
		f.add(p);
		f.setSize(500,500);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	public void itemStateChanged(ItemEvent ie)
	{
		
		if(ie.getItemSelectable()==cb1)
		{
		course="JAVA";
		}
		else if(ie.getItemSelectable()==cb2)
		{
		course=course+",PHP";
		}
		else if(ie.getItemSelectable()==cb3)
		{
		course=course+",C++";
		}
		l1.setText("Course selected by u are : "+course);
	}
public static void main(String [] ar)
	{
		new checkboxevent();
	}

}
