//package pack;

import java.awt.*;
import javax.swing.*;
class progressbardemo extends JFrame
{
public	progressbardemo pdg;
	JFrame f;
	
	JLabel l1;
	Font ft;
	JProgressBar pb;
	int i=1;
	progressbardemo()
	{	
		
		f=new JFrame("hi");
		f.setLayout(null);
		
		ft=new Font("monotype corsiva",Font.BOLD,20);
		l1=new JLabel("My Chat Application");
		l1.setFont(ft);
		l1.setForeground(Color.red);
		l1.setBounds(40,40,400,80);
		pb=new JProgressBar();
		pb.setSize(300,20);
		pb.setBounds(40,100,200,20);
		f.add(l1);
		f.add(pb);
		f.setSize(300,300);
		f.setVisible(true);
		
		Runnable r = new Runnable()
       		 {
		            public void run()
            		           {
                		pb.setMaximum(100);
		                while(true)
                		{
                    			pb.setValue(i++);
                    			try
                    			{
                        				Thread.sleep(100);                        
                			}
                			catch(Exception e)
                			{}
                		if(i==100)
                		{
                 		f.dispose();
                 		new mainform1();
						
                 		break;
                		}
                    		}
        		            }
		 };
    new Thread (r).start();
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
	}
public static void main(String [] ar)
	{
		new progressbardemo();
	}

}