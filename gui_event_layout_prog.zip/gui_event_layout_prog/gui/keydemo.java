import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class keydemo extends JFrame implements KeyListener
{
int y=0;
JFrame f;
JTextField t1,t2;
JLabel l1,l2;
JButton b1;
	keydemo()
	{
		f=new JFrame("h");
		f.setLayout(new FlowLayout());
		l1=new JLabel("name");
		l2=new JLabel("course");
		t1=new JTextField(20);
		t2=new JTextField(20);
		b1=new JButton("Submit");
		t1.addKeyListener(this);
		t2.addKeyListener(this);
		//t2.addMouseListener(this);
		f.add(l1);
		f.add(t1);
		f.add(l2);
		f.add(t2);
		f.add(b1);
		f.setSize(500,600);
		f.setVisible(true);
	}
public void keyPressed(KeyEvent ke)
	{
	if(ke.getSource()==t1)
		{
			String s1=t1.getText();
			if(s1!=null)
			{
				y++;
				if(y>10)
				{
				JOptionPane.showMessageDialog(this,new String("Name should not be less than 10"+y));
				}
				else
				{
				//System.out.println("not");
				}
			}
		}
	
	/*
	if(ke.getSource()==t2)
		{
			String s1=t1.getText();
			if(s1.length()<10)
			{
			JOptionPane.showMessageDialog(this,new String("Name should not be less than 10"));
			}
			else
			{
			System.out.println("not");
			}
		}
	*/
	}
public void keyReleased(KeyEvent ke)
	{
	//System.out.println("Key released");		
	}
public void keyTyped(KeyEvent ke)
	{
		//System.out.println("Key typed");
	}
/*public void mouseEntered(MouseEvent me)
{}
public void mouseExited(MouseEvent me)
{}
public void mousePressed(MouseEvent me)
{
}
public void mouseClicked(MouseEvent me)
{
}
public void mouseReleased(MouseEvent me)
{}*/
public static void main(String [] args)
	{
		new keydemo();	
	}
}