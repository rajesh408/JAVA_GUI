import javax.swing.*;
import java.awt.*;
public class combodemo
{
	JFrame f;
	JPanel p;
	JLabel l1,l2,l3,l4,l5;
	JTextField t1,t2;
	TextArea ta1;
	Font ft;
	JScrollPane sp;
	JComboBox cb1;
	String cour[]={"Select...","C++","JAVA","STRUTS","J2EE","PHP"};
	combodemo()
	{
		
		ft=new Font("algerian",Font.BOLD,30);
		f=new JFrame("Swing Frame Demo.....! ");
		f.setLayout(null);
		p=new JPanel();
		p.setLayout(new GridLayout(5,2,40,40));
		p.setBackground(Color.yellow);
		
		l1=new JLabel("Name");
		l1.setFont(ft);
		l1.setForeground(Color.orange);
		l2=new JLabel("Address");
		l2.setFont(ft);
		l2.setForeground(Color.orange);
		l3=new JLabel("Age");
		l3.setFont(ft);
		l3.setForeground(Color.orange);
		l4=new JLabel("Course");
		l4.setFont(ft);
		l4.setForeground(Color.orange);
		l5=new JLabel("Gender");
		l5.setFont(ft);
		l5.setForeground(Color.orange);
		
		t1=new JTextField(20);
		t2=new JTextField(20);
		
		ta1=new TextArea(3,20);
		sp=new JScrollPane(ta1);
		cb1=new JComboBox(cour);
		cb1.setMaximumRowCount(5);
		
		//p.add(sp);
		p.add(l1);		
		p.add(t1);
		p.add(l2);
		
		p.add(ta1);
		p.add(l3);	
		p.add(t2);			
		p.add(l4);
		p.add(cb1);		
		p.add(l5);		

		p.setSize(300,300);
		p.setVisible(true);
			
		f.add(p);
		f.setSize(500,500);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
		new combodemo();
	}
}