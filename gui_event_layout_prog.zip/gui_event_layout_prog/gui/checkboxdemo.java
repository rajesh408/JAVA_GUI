import javax.swing.*;
import java.awt.*;
public class checkboxdemo
{
	JFrame f;
	JPanel p;
	
	JCheckBox b1,b2,b3;
	
	checkboxdemo()
	{
		
		f=new JFrame("Swing Frame Demo.....! ");
		//f.setLayout(null);
		p=new JPanel();
		p.setBackground(Color.yellow);
		
		
		b1=new JCheckBox("C");
		b2=new JCheckBox("C++");
		b3=new JCheckBox("UML");
		
		p.add(b1);		
		p.add(b2);		
		p.add(b3);		
			

		p.setSize(300,300);
		p.setVisible(true);
		f.add(p);
		f.setSize(500,500);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
		new checkboxdemo();
	}
}