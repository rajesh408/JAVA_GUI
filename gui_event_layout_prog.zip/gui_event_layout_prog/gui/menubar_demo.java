import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class menubar_demo extends JFrame implements MouseListener
{
	JFrame f;
	JMenuBar mb;
	JMenu m1,m2,m3;
	JMenuItem mi1,mi2,mi3;
	JCheckBoxMenuItem mick;
	JFileChooser fc;
	menubar_demo()
	{	
		f=new JFrame("MY Frame Demo...!");
		f.setLayout(null);
		mb=new JMenuBar();
		m1=new JMenu("File");
		
		m2=new JMenu("Format");
		m3=new JMenu("Help");
		mi1=new JMenuItem("Cut");
		mi2=new JMenuItem("Save As...");
		
		mi2.addMouseListener(this);
		
		mi3=new JMenuItem("search");
		mick=new JCheckBoxMenuItem("word wrap");
		m1.add(mi1);
		m1.addSeparator();
		m1.add(mi2);
		m2.add(mick);
		m3.add(mi3);

		mb.add(m1);
		mb.add(m2);
		mb.add(m3);
		f.setJMenuBar(mb);

		f.setSize(400,400);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public void mouseEntered(MouseEvent me)
	{} 
public void mouseExited(MouseEvent me)
	{}
public void mouseReleased(MouseEvent me)
	{}
public void mouseClicked(MouseEvent me)
	{}
public void mousePressed(MouseEvent me)
	{
	
		if(me.getSource()==mi2)
		{
		fc=new JFileChooser();
		int returnValue = fc.showOpenDialog(f);
		}
	}
public static void main(String [] ar)
	{
		new menubar_demo();
	}
}





