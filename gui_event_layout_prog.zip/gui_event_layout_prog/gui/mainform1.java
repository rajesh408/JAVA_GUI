import java.util.Date;
import javax.swing.*;
import java.awt.*;
import javax.swing.UIManager.*;
import javax.swing.BorderFactory;
import javax.swing.border.Border;
import javax.swing.border.EtchedBorder;
public class mainform1
	{
		JFrame f2;
		JPanel p1,p2,p3;
		JLabel l1,l2,l3,l4,L1,L2,L3,L4,L5,L6,L7,L8,L9,L10,L11,L12,L13,L14,L15;
		ButtonGroup bg;
		JRadioButton r1,r2,r3,r4;
		JButton b1,b2,b3,b4;
		Font f,ft2,ft3;
		Border raisedbevel,loweredbevel;
		mainform1()
		{
			try {
    				for (LookAndFeelInfo info : UIManager.getInstalledLookAndFeels())
				 {
        					if ("Nimbus".equals(info.getName())) 
					{
	            				UIManager.setLookAndFeel(info.getClassName());
           					 break;
        			   		}
   			    	}
			    }
			 catch (Exception e)
			 {
    				// If Nimbus is not available, you can set the GUI to another look and feel.
			}
		f2=new JFrame("MAIN FRAME");
		f2.setLayout(null);

		f=new Font("Algerian",Font.BOLD,30);
		ft2=new Font("Arial",Font.BOLD,20);
		ft3=new Font("Arial",Font.BOLD,25);
		raisedbevel = BorderFactory.createRaisedBevelBorder();
		loweredbevel = BorderFactory.createLoweredBevelBorder();	
	
		p1=new JPanel(); 
		p1.setLayout(null);
		p1.setBackground(new Color(255,204,153));
		p1.setBorder(BorderFactory.createLineBorder(new Color(204,0,0)));
		p1.setBounds(10,50,580,200);
		p1.setVisible(true);
		l1=new JLabel("YOUR TIME STARTS NOW");
		//l1.setSize(60,30);
		l1.setForeground(new Color(153,51,0));
		l1.setBounds(70,50,500,20);
		l1.setFont(f);
		l4= new JLabel(" ");
		l4.setBounds(250,120,200,30);
		p1.add(l1);
		b1=new JButton("START");
       		b1.setBounds(110,120, 100, 30);
		b1.setBackground(Color.gray);
		p1.add(b1);
		p1.add(l4);

		p2=new JPanel();
        		p2.setLayout(null);
		p2.setBounds(10,300,580,370);
		p2.setBorder(BorderFactory.createCompoundBorder(raisedbevel, loweredbevel));
       		p2.setBackground(new Color(255,255,204));

       		l2=new JLabel("Q. Who is richest person in the world ?"); 
        		l2.setBackground(Color.green);
        		l2.setBounds(50,20,550,40);
       		l2.setForeground(new Color(0,102,102));
		l2.setFont(ft2);
        		l3=new JLabel("OPTIONS:");
        		l3.setBounds(140,60,200,50);
       		l3.setForeground(Color.blue);
		l3.setFont(ft3);
        		bg= new ButtonGroup();
		
		r1=new JRadioButton("ans1");
		r1.setBounds(50,120,300,20);
		r2=new JRadioButton("ans2");
		r2.setBounds(50,160,300,20);
		r3=new JRadioButton("ans3");
		r3.setBounds(50,200,300,20);
		r4=new JRadioButton("ans4");
		r4.setBounds(50,240,300,20);
        		bg.add(r1);
		bg.add(r2);
       		bg.add(r3);
		bg.add(r4);

        		p2.add(l2);
		p2.add(l3);
        		p2.add(r1);
       		p2.add(r2);
       		p2.add(r3);
        		p2.add(r4); 
        		p2.setVisible(true);
	
        
        		p3=new JPanel();
      		p3.setLayout(null);
		p3.setBounds(600,80,390,100);
      
       		// p3.add(b4);
       		p3.setLayout(new GridLayout(1, 3));
	                p3.add(new JButton("50-50"));
	                p3.add(new JButton("SKIP"));
	                p3.add(new JButton("AUDIENCE VOTE"));
                                p3.setVisible(true);

      		//  Box hBox = Box.createHorizontalBox();
      		// hBox.add(new JButton("50-50"));
     		//hBox.add(new JButton("SKIP"));
   		//hBox.add(new JButton("AUDIENCE VOTE"));
   		//f2.getContentPane().add(hBox, BorderLayout.CENTER);
  		//p3.add(hBox);
       
        		L1= new JLabel("2,00,00,000");
        		L1.setBounds(750,200,200,200);
		L1.setBackground(Color.blue);
		L2= new JLabel("1,00,00,000");
       		L2.setBounds(750,220,200,200);
       		L3= new JLabel("50,00,000");
       		L3.setBounds(750,240,200,200);
      		L4= new JLabel("50,00,000");
      		L4.setBounds(750,240,200,200);
        		L5= new JLabel("12,50,000");
       		L5.setBounds(1200,280,200,200);
       		L6= new JLabel("6,40,000");
       		L6.setBounds(750,300,200,200);
       		L7= new JLabel("3,20,000");
        		L7.setBounds(750,320,200,200);
       		L8= new JLabel("1,60,000");
       		L8.setBounds(750,340,200,200);
       		L9= new JLabel("80,000");
       		L9.setBounds(750,360,200,200);
       		L10= new JLabel("40,000");
       		L10.setBounds(750,380,200,200);
       		L11= new JLabel("20,000");
     		L11.setBounds(750,400,200,200);
      		L12= new JLabel("10,000");
       		L12.setBounds(1200,420,200,200);
        		L13= new JLabel("5,000");
       		L13.setBounds(750,440,200,200);
       		L14= new JLabel("3,000");
       		L14.setBounds(750,460,200,200);
       		L15= new JLabel("1,000");
        		L15.setBounds(750,480,200,200);
        		f2.add(L1);
      		f2.add(L2);
        		f2.add(L3);	
        		f2.add(L4);	     
        		f2.add(L5);
       		f2.add(L6);
        		f2.add(L7);
        		f2.add(L8);
        		f2.add(L9);
        		f2.add(L10);
        		f2.add(L11);
        		f2.add(L12);
        		f2.add(L13);
        		f2.add(L14);
        		f2.add(L15);
        
        
       		f2.add(p1);
        		f2.add(p2);
		f2.add(p3);

        		f2.setSize(1024,768);
		f2.setVisible(true);
        f2.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        Runnable r=new Runnable()
		{
			public void run()
			{
				while(f2!=null)
				{
					l4.setText(new java.util.Date().toString());
					try
					{
						Thread.sleep(1000);
					}
					catch(Exception e){}
				}
			}
		};
		new Thread(r).start();
	} 
      
		public static void main(String []args)
		{
			new mainform1();
		}
        
        
	}