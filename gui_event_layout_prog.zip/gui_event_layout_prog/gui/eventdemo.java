import java.awt.*;
import java.awt.event.*;
import javax.swing.*;
class eventdemo extends JFrame implements ActionListener
{
	JFrame f;
	JPanel p;
	JLabel l1,l2;
	JTextField t1;
	JButton b1;
	
	public eventdemo()
	{
		f=new JFrame("Event Demo.........!");
		f.setLayout(null);
		p=new JPanel();
		l1=new JLabel("Enter u R Name :");
		l2=new JLabel("");
		t1=new JTextField(20);
		b1=new JButton("Submit");
		
		b1.addActionListener(this);

		p.add(l1);
		p.add(t1);
		p.add(b1);
		p.add(l2);
		p.setSize(400,400);
		p.setVisible(true);
		f.add(p);
		f.setSize(400,400);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==b1)
			{
				String s1=t1.getText();
				l2.setText("Welcome Mr/Ms "+s1);
				t1.setText("");
			}
		}
public static void main(String []arg)
		{
			new eventdemo();
		}
}