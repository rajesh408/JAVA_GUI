import java.awt.*;
import javax.swing.*;
class hrframe1 extends JFrame
{
	JFrame f;
	JPanel p1;
	JLabel l1;
	JButton b1;
	ImageIcon img;
	hrframe1()
	{
		f=new JFrame("Harleen Frame");
		b1=new JButton("submit");
		
		img=new ImageIcon("gg.jpg");
		l1=new JLabel("",img,JLabel.CENTER);
		
		b1.setIcon(img);
		p1=new JPanel();
		
		p1.add(l1);
		p1.add(b1);
		
		p1.setSize(150,150);
		
		p1.setVisible(true);
		
		
		p1.setBackground(Color.green);
	
		f.add(p1);

		f.setSize(500,600);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
	}
public static void main(String [] arg)
	{
	new hrframe1();
	}
}
