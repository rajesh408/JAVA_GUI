import java.awt.event.*;
import javax.swing.*;
class mouselistenerdemo extends JFrame implements MouseListener,MouseMotionListener,KeyListener
{
	JFrame f;
	JLabel l1,l2;
	ImageIcon ic;
	JTextField t1,t2;
	int x,y;
	mouselistenerdemo()
	{
	
	f=new JFrame("Mouse Listener Demo....!");
	f.setLayout(null);
	ic=new ImageIcon("gg.jpg");
	l2=new JLabel("Enter ur age");
	l2.setBounds(100,400,150,20);
	t2=new JTextField(20);
	t2.setBounds(200,400,200,20);
	l1=new JLabel("My Star",ic,JLabel.CENTER);
	l1.setVisible(false);
	l1.setBounds(200,20,200,200);
	t1=new JTextField(20);
	t1.setBounds(150,200,200,20);
	f.addMouseListener(this);
	f.addMouseMotionListener(this);
	t2.addKeyListener(this);

	f.add(l1);
	f.add(t1);
		f.add(l2);
		f.add(t2);
	f.setSize(600,600);
	f.setVisible(true);
	f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public void mousePressed(MouseEvent me)
	{
	x=me.getX();
	y=me.getY();
	t1.setText("Mouse pressed at X : "+x+" & Y : "+y);
	}

public void mouseClicked(MouseEvent me)
	{
	x=me.getX();
	y=me.getY();
	t1.setText("Mouse clicked at X : "+x+" & Y : "+y);
	}
public void mouseEntered(MouseEvent me)
	{
	l1.setVisible(true);
	x=me.getX();
	y=me.getY();
	t1.setText("Mouse entered at X : "+x+" & Y : "+y);
	}
public void mouseExited(MouseEvent me)
	{
		l1.setVisible(false);
	x=me.getX();
	y=me.getY();
	t1.setText("Mouse exited at X : "+x+" & Y : "+y);
	}
public void mouseReleased(MouseEvent me)
	{
	x=me.getX();
	y=me.getY();
	t1.setText("Mouse released at X : "+x+" & Y : "+y);
	}
public void mouseMoved(MouseEvent me)
	{
	x=me.getX();
	y=me.getY();
	l1.setBounds(x,y,200,200);
	t1.setText("Mouse moved at X : "+x+" & Y : "+y);
	}
public void keyPressed(KeyEvent ke)
	{
if(ke.getKeyCode()>=48 && ke.getKeyCode()<=57)
		{
		}
		else
		{
		JOptionPane.showMessageDialog(this,new String("Please enter a numeric value......!"));
		t2.setText("");
		}
	}

public void keyTyped(KeyEvent ke)
	{
		JOptionPane.showMessageDialog(this,new String("Key Type"));			
	}

public void keyReleased(KeyEvent ke)
	{
		JOptionPane.showMessageDialog(this,new String("Key Released"));
	}
public void mouseDragged(MouseEvent me)
	{}
public static void main(String arg[])
	{
		new mouselistenerdemo();
	}
}