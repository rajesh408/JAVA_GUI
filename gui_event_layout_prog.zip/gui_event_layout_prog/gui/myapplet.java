import java.applet.*;
import java.awt.*;
public class myapplet extends Applet
{
	String s;

	public void start()
	{
		setBackground(Color.GREEN);
		s = s + "Start";
	}

	public void init()
	{
		s = "init";
	}

	public void paint(Graphics g)
	{
		s = s + "Paint";
		g.drawString(s,30,30);
	}

	
}