import javax.swing.*;
import java.awt.*;
public class passwordfielddemo
{
	JFrame f;
	JPanel p;
	
	JPasswordField p1;
	
	passwordfielddemo()
	{
		
		f=new JFrame("Swing Frame Demo.....! ");
		//f.setLayout(null);
		p=new JPanel();
		p.setBackground(Color.yellow);
		
		
		p1=new JPasswordField(20);
		p1.setEchoChar('@');
		
		p.add(p1);			
			
		p.setSize(300,300);
		p.setVisible(true);
		f.add(p);
		f.setSize(500,500);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public static void main(String [] ar)
	{
		new passwordfielddemo();
	}
}