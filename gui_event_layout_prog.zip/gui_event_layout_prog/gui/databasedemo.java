import javax.sql.*;
import java.sql.*;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
class databasedemo extends JFrame implements ActionListener
{
	JFrame f;
	JPanel p;
	JLabel l1,l2,l3;
	JTextField t1,t2,t3;
	JButton b1;
	
	public databasedemo()
	{
		f=new JFrame("DataBase Demo..........!");
		f.setLayout(null);
		p=new JPanel();
		p.setLayout(new GridLayout(4,2));
		l1=new JLabel("SID");
		l2=new JLabel("NAME");
		l3=new JLabel("AGE");
		t1=new JTextField(20);
		t2=new JTextField(20);
		t3=new JTextField(20);
		b1=new JButton("Submit");
		b1.addActionListener(this);
		p.add(l1);
		p.add(t1);
		p.add(l2);
		p.add(t2);
		p.add(l3);
		p.add(t3);
		p.add(b1);
		
		p.setSize(400,200);
		p.setVisible(true);
		f.add(p);
		f.setSize(500,500);
		f.setVisible(true);
		f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
public void actionPerformed(ActionEvent ae)
		{
			if(ae.getSource()==b1)
			{
			String s1=t1.getText();
			String s2=t2.getText();
			String s3=t3.getText();
			int ss3=Integer.parseInt(s3);
			try
				{
					//Class.forName("com.mysql.jdbc.Driver");

					Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/ankit","root","root");
					PreparedStatement ps=con.prepareStatement("insert into student values(?,?,?)");
					ps.setString(1,s1);
					ps.setString(2,s2);
					ps.setInt(3,ss3);
					int rs=ps.executeUpdate();
					if(rs>0)
					{
					JOptionPane.showMessageDialog(this,new String("Data inserted successfully......!"));
					}
					else
					{
					JOptionPane.showMessageDialog(this,new String("Data failed to insert......!"));
					}
			}
		
			catch(Exception e)
			{
			System.out.println("Error "+e);
			}
				
			}
		} 
	public static void main(String [] ar)
	{
	new databasedemo();	
		
	}
}