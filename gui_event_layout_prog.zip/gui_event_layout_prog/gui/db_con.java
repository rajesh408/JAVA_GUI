import javax.sql.*;
import java.sql.*;
public class db_con
{
	public static void main(String [] args)
	{
		try
		{
		Class.forName("com.mysql.jdbc.Driver");
		Connection con=DriverManager.getConnection("jdbc:mysql://localhost:3306/arena","root","root");
		System.out.println("connection established successfully..!");
		PreparedStatement ps=con.prepareStatement("select * from faculty");
		ResultSet rs=ps.executeQuery();
		System.out.println("Fid \t Name \t qual.");
		while(rs.next())
		{
			System.out.println(rs.getString(1)+"\t"+rs.getString(2)+"\t"+rs.getString(3));
			
		}
		}
		catch(Exception e)
		{
			System.out.println("error"+e);
		}
		
		
	}
}
