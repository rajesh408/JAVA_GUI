public class fabianprog
{
	public static void main(String [] ar)
	{
	System.out.println("Hello Fabian...!");	
	}
}